package com.example.tagapp;

public interface Constants {
	String LOG = "com.example.tagbincam";
}
